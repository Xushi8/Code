目前存在两个已创建用户：
commonuser、goodstudent
密码与用户名相同